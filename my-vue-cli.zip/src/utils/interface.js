export default {
  map: {
    initData: '/interface/init.html',
    login: '/interface/login.html',
    getAuthor: '/interface/getAuthor.html',
    updateServerToken:'/interface/updateServerToken.html'
  }
}
